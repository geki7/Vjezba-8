﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Products
{
    public partial class FrmProducts : Form
    {
        public FrmProducts()
        {
            InitializeComponent();
        }

        private void FrmProducts_Load(object sender, EventArgs e)
        {

        }

        private void btnShowProducts_Click(object sender, EventArgs e)
        {
           
        }

        private void btnUpdatePrice_Click(object sender, EventArgs e)
        {

        }
    }
}
