﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Employees
{
    class Job
    {
        public int JobId { get; set; }
        public string JobDesc { get; set; }

        public override string ToString()
        {
            return JobDesc;
        }
    }
}
