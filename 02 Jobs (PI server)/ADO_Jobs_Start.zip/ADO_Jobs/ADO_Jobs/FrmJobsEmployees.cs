﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Jobs
{
    public partial class FrmJobsEmployees : Form
    {
        public FrmJobsEmployees()
        {
            InitializeComponent();
        }

        private void FrmJobsEmployees_Load(object sender, EventArgs e)
        {
  
        }

        private void dgvJobs_SelectionChanged(object sender, EventArgs e)
        {
    
        }

        private void btnAddJob_Click(object sender, EventArgs e)
        {

        }
    }
}
